const cards = document.getElementById('cards')
const templateCard = document.getElementById('template-card').content
const items = document.getElementById('items')
const footer = document.getElementById('footer')
const templateFooter = document.getElementById('template-footer').content
const templateCarrito = document.getElementById('template-carrito').content
const fragment = document.createDocumentFragment()
const path = "http://localhost:8080";
let carrito = {}

const linkBase = "192.168.1.9:8080";
const linkPlatos = 

document.addEventListener('DOMContentLoaded', ()=>{
	fetchData()
	if(localStorage.getItem('carrito')){
		carrito = JSON.parse(localStorage.getItem('carrito'))
		pintarCarrito()
	}
}
)

cards.addEventListener('click', e =>{
	addCarrito(e)
})

items.addEventListener('click', e=>{
	btnAccion(e)
})

const fetchData = async()=>{
	try{
		const res = await fetch(path + "/menu/disponible")
		const data = await res.json()
		data.categoriasDisponibles.forEach(categoria => {
			pintarCard(categoria.platos);
		}
		);

	}catch(error){
		console.log(error)
	}
}

const pintarCard = data=>{
	data.forEach(item => {
		templateCard.querySelector('h5').textContent = item.nombre
		templateCard.querySelector('p').textContent = item.precio
		templateCard.querySelector('img').setAttribute('src', item.imagen)
		templateCard.querySelector('.btn-dark').dataset.id = item.id
		const clone = templateCard.cloneNode(true)
		fragment.appendChild(clone)
	})
	cards.appendChild(fragment)
}

const addCarrito = e =>{
	//console.log(e.target)
	//console.log(e.target.classList.contains('btn-dark'))
	if(e.target.classList.contains('btn-dark')){
		setCarrito(e.target.parentElement)
	}

e.stopPropagation()
}



const setCarrito = item => {
	//console.log(objeto)
	const producto = {
		title: item.querySelector('h5').textContent,
		precio: item.querySelector('p').textContent,
		id: item.querySelector('.btn-dark').dataset.id,
		cantidad: 1
	}

	if(carrito.hasOwnProperty(producto.id)){
		producto.cantidad = carrito[producto.id].cantidad + 1
	}

	carrito[producto.id] = { ...producto}
	pintarCarrito()
}

const pintarCarrito = ()=> {
	
	items.innerHTML = ''
	Object.values(carrito).forEach(producto => {
		templateCarrito.querySelector('th').textContent = producto.id
		//ocultar el numero de id
		templateCarrito.querySelector('th').style.display = 'none'
		templateCarrito.querySelectorAll('td')[0].textContent = producto.title
		templateCarrito.querySelectorAll('td')[1].textContent = producto.cantidad
		templateCarrito.querySelector('.btn-info').dataset.id = producto.id
		templateCarrito.querySelector('.btn-danger').dataset.id = producto.id
		templateCarrito.querySelector('span').textContent = producto.cantidad * producto.precio
		const clone = templateCarrito.cloneNode(true)
		fragment.appendChild(clone)
	})

	items.appendChild(fragment)

	pintarFooter()

	localStorage.setItem('carrito', JSON.stringify(carrito))

}


const pagar = async () => {
	if (Object.keys(carrito).length === 0) {
	  alert('El carrito está vacío. Agregue productos antes de pagar.');
	  return;
	}
	const pedido = {
	  pedidoProductosList: Object.values(carrito).map(({ id, cantidad }) => ({
		producto:{id:id},
		cantidad,
	  })),
	  total: Object.values(carrito).reduce(
		(acc, { cantidad, precio }) => acc + cantidad * precio,
		0
	  )	
	};
  
	console.log(pedido);
  
	 await crearPedido(pedido);
	carrito = {};
	localStorage.setItem('carrito', JSON.stringify(carrito));
	items.innerHTML = '';
	pintarFooter();
  };

  crearPedido = async (pedido) => {
	try {
	  const res = await fetch(path + "/pedido", {
		method: "POST",
		headers: {
		  "Content-Type": "application/json",
		},
		body: JSON.stringify(pedido),
	  });
	  const data = await res.json();
	  
	console.log(data);
	if (res.status === 201) {
		document.getElementById("idPedido").value = data.id;
        var modal = new bootstrap.Modal(document.getElementById('myModal'));
		modal.show();
	} else {
	  alert('Hubo un error al crear el pedido');
	}
	} catch (error) {
	console.log(error);
	}
	  };

const pintarFooter = () => {
		footer.innerHTML = ''
		if(Object.keys(carrito).length === 0){
			footer.innerHTML = `
			<th scope="row" colspan="5">Carrito vacío - comience a comprar!</th>
			`
			return
		}

		const nCantidad = Object.values(carrito).reduce((acc, {cantidad})=> acc + cantidad, 0)
		const nPrecio = Object.values(carrito).reduce((acc, {cantidad, precio}) => acc + cantidad * precio, 0)
		
		templateFooter.querySelectorAll('td')[0].textContent = nCantidad
		templateFooter.querySelector('span').textContent = nPrecio
	
		const clone = templateFooter.cloneNode(true)
		fragment.appendChild(clone)
		footer.appendChild(fragment)
	
		const btnVaciar = document.getElementById('vaciar-carrito')
		btnVaciar.addEventListener('click', ()=>{
			carrito = {}
			pintarCarrito()
		})
		const btnPagar = document.getElementById('pagar')
		btnPagar.addEventListener('click', ()=>{
			pagar()
		})
	}

	function redireccion(x){
		var id = document.getElementById("idPedido").value;
		if(x=="w"){
		window.open("https://api.whatsapp.com/send?phone=573195569543&text=Hola%2C%20Quiero%20obtener%20informacion%20de%20mi%20pedido%20"+id+"%20del%20Restaurante%20la%20Fontana", "_blank");
		window.location.href = "./";}
		else
		window.location.href = "./";
	}
const btnAccion = e =>{
	
	if(e.target.classList.contains('btn-info')){
		
		const producto = carrito[e.target.dataset.id]
		producto.cantidad++

		carrito[e.target.dataset.id] = {...producto}
		pintarCarrito()
	}

	if(e.target.classList.contains('btn-danger')){
		const producto = carrito[e.target.dataset.id]
		producto.cantidad--
		if(producto.cantidad ===0){
			delete carrito[e.target.dataset.id]
		}
		pintarCarrito()

	}

	e.stopPropagation()
}