const path = "http://localhost:8080";
getMenuDisponible();
function getMenuDisponible(){
    fetch(path + "/menu")
    .then(response => response.json())
    .then(data => {
        cargaZonaMenu(data.categoriasDisponibles);
    })
}

function cargaZonaMenu(categoriasDisponibles){
    document.getElementById("menu").innerHTML = 
    `<div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2>Menu</h2>
      <p>Consulta Nuestro Sabroso Menú</p>
    </div>
    <div class="row" data-aos="fade-up" data-aos-delay="100">
      <div class="col-lg-12 d-flex justify-content-center">
        <ul id="menu-flters">
        <li data-filter="*" class="filter-active">Todo</li>
        ${cargarCategorias(categoriasDisponibles)}
        </ul>
      </div>
    </div>

    <div class="row menu-container" data-aos="fade-up" data-aos-delay="200" id="platosMenu">
       ${cargarPlatos(categoriasDisponibles)}
    </div>`;
  setTimeout(() => {
    console.log("carga");
    let menuContainer = select('.menu-container');
  if (menuContainer) {
    let menuIsotope = new Isotope(menuContainer, {
      itemSelector: '.menu-item',
      layoutMode: 'fitRows'
    });

    let menuFilters = select('#menu-flters li', true);

    on('click', '#menu-flters li', function(e) {
      e.preventDefault();
      menuFilters.forEach(function(el) {
        el.classList.remove('filter-active');
      });
      this.classList.add('filter-active');

      menuIsotope.arrange({
        filter: this.getAttribute('data-filter')
      });
      menuIsotope.on('arrangeComplete', function() {
        AOS.refresh()
      });
    }, true);
  }} , 500);
}

function cargarCategorias(categorias){
  let aux="";
  categorias.forEach(categoria => {
    aux += `<li data-filter=".filter-${categoria.descripcion}">${categoria.nombre}</li>`;
  });
  return aux;
}

function cargarPlatos(categorias){
  let menu="";
  console.log(categorias);
  categorias.forEach(categoria => {
    categoria.platos.forEach(plato => { menu+= 
      `<div class="col-lg-6 menu-item filter-${categoria.descripcion}">
        <img src="${plato.imagen}" class="menu-img" alt="">
        <div class="menu-content">
          <a href="javascript:agregarAlCarrito('',${plato.precio});">${plato.nombre}</a><span>$${plato.precio}</span>
        </div>
        <div class="menu-ingredients">
          ${plato.descripcion}
        </div>
        
        <div class="d-flex justify-content-end" style="margin-top: 10px;">
        <span style="margin-right: 10px;"> 
            <a href="#"><i class="bi bi-pencil-square"></i></a>
        </span> 
        <span style="margin-right: 10px;">
            <a href="#"><i class="bi bi-file-x"></i></a>
        </span>
        <span>
            <a href="javascript:ocultarplato('${plato.id}');"><i class="bi bi-eye${plato.estado==false?'-slash':''}"></i></a>
        </span>
    </div>
      </div>`;
    });
  });
  return menu;
}

function ocultarplato(id){
  fetch(path + "/productos/"+id+"/disponibilidad",
    {
        method: 'PUT'
    }
  )
  .then(response => response.json())
  .then(data => {
    getMenuDisponible();
  })
}
